"""
Some functions to help cleaning and handling dataframes.
"""

import pandas as pd

def report_missing_values(df):
    """Print a pretty report of missing values."""
    print('Need to write code here!')