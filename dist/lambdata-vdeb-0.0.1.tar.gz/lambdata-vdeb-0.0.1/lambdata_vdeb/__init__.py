"""
lambdata - a collection of encouragement
"""

import pandas as pd
import numpy as np 
import random
from random import seed
from random import randint
from lambdata_vdeb.dataframe_Helper import report_missing_values


TEST = pd.DataFrame(np.ones(10))